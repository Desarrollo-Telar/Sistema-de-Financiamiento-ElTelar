export function calculo_interes(saldo_pendiente, tasa_credito){
    return parseFloat(saldo_pendiente) * parseFloat(tasa_credito)
}