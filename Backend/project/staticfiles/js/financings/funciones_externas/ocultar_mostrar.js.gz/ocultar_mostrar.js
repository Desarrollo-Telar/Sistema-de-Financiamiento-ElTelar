export const ocultar = (element) => {
    if (element) {
        element.style.display = 'none';
    }
};

export const mostrar = (element) => {
    if (element) {
        element.style.display = 'block';
    }
};